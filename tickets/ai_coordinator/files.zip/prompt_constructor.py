#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prompt Constructor
===================

Настольное приложение (Tkinter) для интерактивной сборки промптов
из заранее подготовленных шаблонов (*.txt), лежащих рядом с программой.

Формат шаблона описан в ТЗ:

    [SECTION name=... class=... default=1]
    ...текст / вложенные SECTION...
    [/SECTION]

Используется только стандартная библиотека Python.
"""

import os
import re
import sys
import configparser
import tkinter as tk
from tkinter import ttk, messagebox

CONFIG_FILE = "prompt_constructor.ini"
TICKET_PLACEHOLDER = "{{TICKET}}"

# --------------------------------------------------------------------------
# Разбор шаблонов
# --------------------------------------------------------------------------


class TemplateParseError(Exception):
    """Ошибка разбора шаблона — файл не может быть использован для генерации."""

    def __init__(self, filename, line, message):
        self.filename = filename
        self.line = line
        self.message = message
        super().__init__(f"{filename}, строка {line}: {message}")


class Section:
    """Один узел SECTION в дереве шаблона."""

    __slots__ = ("name", "cls", "default", "enabled", "children", "line")

    def __init__(self, name, cls, default, line):
        self.name = name
        self.cls = cls
        self.default = default   # bool — состояние после Reset
        self.enabled = default   # bool — текущее состояние (до применения INI)
        self.children = []       # список: str | Section
        self.line = line


_TAG_RE = re.compile(r"\[SECTION([^\]]*)\]|\[/SECTION\]")
_ATTR_RE = re.compile(r'(\w+)\s*=\s*"([^"]*)"|(\w+)\s*=\s*(\S+)')


def _parse_attrs(attr_str):
    attrs = {}
    for m in _ATTR_RE.finditer(attr_str):
        if m.group(1) is not None:
            key, val = m.group(1), m.group(2)
        else:
            key, val = m.group(3), m.group(4)
        attrs[key] = val
    return attrs


def _parse_default(raw):
    """default отсутствует -> True; default=1 -> True; default=0 -> False.
    Прочие значения не используются -> трактуем как отсутствие (True)."""
    if raw is None:
        return True
    if raw == "1":
        return True
    if raw == "0":
        return False
    return True


def parse_template(text, filename):
    """Разбирает содержимое файла в дерево узлов (список str | Section).

    Бросает TemplateParseError при незакрытой/лишней закрывающей секции.
    """
    pos = 0
    root = []
    stack = [root]        # стек списков-контейнеров (текущие "children")
    open_sections = []    # стек открытых Section (для проверки закрытия)

    for m in _TAG_RE.finditer(text):
        pre = text[pos:m.start()]
        if pre:
            stack[-1].append(pre)
        pos = m.end()

        if m.group(0) == "[/SECTION]":
            if not open_sections:
                line = text.count("\n", 0, m.start()) + 1
                raise TemplateParseError(
                    filename, line,
                    "Обнаружен закрывающий тег [/SECTION] без соответствующего "
                    "открывающего тега (лишняя или пересекающаяся секция)."
                )
            open_sections.pop()
            stack.pop()
        else:
            attrs = _parse_attrs(m.group(1) or "")
            line = text.count("\n", 0, m.start()) + 1
            sec = Section(
                name=attrs.get("name"),
                cls=attrs.get("class"),
                default=_parse_default(attrs.get("default")),
                line=line,
            )
            stack[-1].append(sec)
            open_sections.append(sec)
            stack.append(sec.children)

    tail = text[pos:]
    if tail:
        stack[-1].append(tail)

    if open_sections:
        unclosed = open_sections[-1]
        raise TemplateParseError(
            filename, unclosed.line,
            "Не найден закрывающий тег [/SECTION] для секции, открытой здесь."
        )

    return root


def iter_sections(nodes):
    """Рекурсивно обходит все Section в дереве (в порядке появления)."""
    for n in nodes:
        if isinstance(n, Section):
            yield n
            yield from iter_sections(n.children)


def validate_unique_names(nodes, filename):
    """В пределах одного файла имя (name) должно быть уникальным."""
    seen = set()
    for sec in iter_sections(nodes):
        if sec.name:
            if sec.name in seen:
                raise TemplateParseError(
                    filename, sec.line,
                    f"Повторяющееся имя секции name='{sec.name}' в пределах одного файла."
                )
            seen.add(sec.name)


def render(nodes):
    """Собирает итоговый текст: выключенные секции и управляющие теги удаляются."""
    out = []
    for n in nodes:
        if isinstance(n, str):
            out.append(n)
        else:
            if n.enabled:
                out.append(render(n.children))
    return "".join(out)


# --------------------------------------------------------------------------
# Приложение
# --------------------------------------------------------------------------


class PromptConstructorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Prompt Constructor")
        self.geometry("1100x700")

        # High DPI: по возможности используем табличный scaling Tk (лучшее,
        # что доступно средствами стандартной библиотеки).
        try:
            self.tk.call("tk", "scaling", 1.3)
        except tk.TclError:
            pass

        self.files = {}          # filename -> {"nodes": [...]} (только валидные)
        self.class_registry = {} # cls -> [Section, ...] (across all files)
        self.section_vars = {}   # Section -> tk.BooleanVar

        self.ticket_var = tk.StringVar()
        self.status_var = tk.StringVar(value="")
        self.dirty_var = tk.StringVar(value="")

        self._suppress_modified = False
        self.text_dirty = False

        self.config_parser = configparser.ConfigParser()
        self._saved_states = {}
        self._saved_ticket = ""
        self._saved_last_tab = ""

        self._load_config()
        errors = self._load_templates()
        self._build_ui()
        self._restore_last_tab()

        if errors:
            messagebox.showerror(
                "Ошибки в шаблонах",
                "Следующие файлы содержат ошибки и не будут использоваться "
                "для генерации:\n\n" + "\n\n".join(errors),
            )

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------------------------------------------------- config ----

    def _load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                self.config_parser.read(CONFIG_FILE, encoding="utf-8")
            except (configparser.Error, OSError):
                pass
        self._saved_ticket = self.config_parser.get("General", "ticket", fallback="")
        self._saved_last_tab = self.config_parser.get("General", "last_tab", fallback="")
        if self.config_parser.has_section("States"):
            self._saved_states = dict(self.config_parser["States"])
        self.ticket_var.set(self._saved_ticket)

    def _save_config(self):
        cfg = configparser.ConfigParser()
        cfg["General"] = {
            "ticket": self.ticket_var.get(),
            "last_tab": self._current_tab_filename() or "",
        }
        states = {}
        for filename, data in self.files.items():
            for sec in iter_sections(data["nodes"]):
                if sec.name:
                    states[f"{filename}.{sec.name}"] = "true" if sec.enabled else "false"
        cfg["States"] = states
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                cfg.write(f)
        except OSError as e:
            messagebox.showwarning("Сохранение настроек", f"Не удалось сохранить настройки: {e}")

    # -------------------------------------------------------- templates ---

    def _load_templates(self):
        errors = []
        try:
            filenames = sorted(
                f for f in os.listdir(".")
                if f.lower().endswith(".txt") and os.path.isfile(f)
            )
        except OSError as e:
            errors.append(f"Не удалось прочитать каталог: {e}")
            filenames = []

        for filename in filenames:
            try:
                with open(filename, "r", encoding="utf-8") as fh:
                    content = fh.read()
            except UnicodeDecodeError:
                errors.append(f"{filename}: файл не в кодировке UTF-8.")
                continue
            except OSError as e:
                errors.append(f"{filename}: не удалось прочитать файл ({e}).")
                continue

            try:
                nodes = parse_template(content, filename)
                validate_unique_names(nodes, filename)
            except TemplateParseError as e:
                errors.append(str(e))
                continue

            # применяем сохранённые состояния именованных секций
            for sec in iter_sections(nodes):
                if sec.name:
                    key = f"{filename}.{sec.name}"
                    if key in self._saved_states:
                        sec.enabled = self._saved_states[key].strip().lower() in (
                            "1", "true", "yes", "on"
                        )
                if sec.cls:
                    self.class_registry.setdefault(sec.cls, []).append(sec)

            self.files[filename] = {"nodes": nodes}

        return errors

    # --------------------------------------------------------------- UI ---

    def _build_ui(self):
        paned = ttk.Panedwindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True)

        left_frame = ttk.Frame(paned, padding=6)
        right_frame = ttk.Frame(paned, padding=6)
        paned.add(left_frame, weight=1)
        paned.add(right_frame, weight=1)

        # --- верх левой панели: Ticket / Generate / Reset ---
        top_bar = ttk.Frame(left_frame)
        top_bar.pack(fill="x", pady=(0, 6))

        ttk.Label(top_bar, text="Ticket:").pack(side="left")
        ticket_entry = ttk.Entry(top_bar, textvariable=self.ticket_var, width=20)
        ticket_entry.pack(side="left", padx=(4, 10))

        ttk.Button(top_bar, text="Generate", command=self.on_generate).pack(side="left", padx=2)
        ttk.Button(top_bar, text="Reset", command=self.on_reset).pack(side="left", padx=2)

        # --- вкладки (Notebook), по одной на файл ---
        self.notebook = ttk.Notebook(left_frame)
        self.notebook.pack(fill="both", expand=True)

        if not self.files:
            empty = ttk.Frame(self.notebook)
            ttk.Label(
                empty,
                text="В текущем каталоге не найдено ни одного *.txt шаблона.",
                padding=20,
            ).pack()
            self.notebook.add(empty, text="(пусто)")
        else:
            for filename in sorted(self.files):
                tab_container, inner = self._make_scrollable_tab(self.notebook)
                self.build_section_widgets(inner, self.files[filename]["nodes"], 0)
                self.notebook.add(tab_container, text=filename)

        # --- правая панель: результат ---
        editor_bar = ttk.Frame(right_frame)
        editor_bar.pack(fill="x")
        ttk.Label(editor_bar, text="Результат:").pack(side="left")
        ttk.Label(editor_bar, textvariable=self.dirty_var, foreground="#b35c00").pack(
            side="left", padx=8
        )

        text_frame = ttk.Frame(right_frame)
        text_frame.pack(fill="both", expand=True, pady=(4, 4))

        self.output_text = tk.Text(text_frame, wrap="word", undo=True)
        out_scroll = ttk.Scrollbar(text_frame, orient="vertical", command=self.output_text.yview)
        self.output_text.configure(yscrollcommand=out_scroll.set)
        self.output_text.pack(side="left", fill="both", expand=True)
        out_scroll.pack(side="right", fill="y")
        self.output_text.bind("<<Modified>>", self._on_text_modified)

        bottom_bar = ttk.Frame(right_frame)
        bottom_bar.pack(fill="x")
        ttk.Button(bottom_bar, text="Copy", command=self.on_copy).pack(side="left")
        ttk.Label(bottom_bar, textvariable=self.status_var, foreground="#666666").pack(
            side="left", padx=10
        )

    def _make_scrollable_tab(self, parent):
        container = ttk.Frame(parent)
        canvas = tk.Canvas(container, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)

        def _on_inner_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))

        inner.bind("<Configure>", _on_inner_configure)
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

        return container, inner

    def build_section_widgets(self, parent, nodes, depth):
        """Рекурсивно строит дерево чекбоксов (только узлы SECTION)."""
        for sec in [n for n in nodes if isinstance(n, Section)]:
            row = ttk.Frame(parent)
            row.pack(fill="x", anchor="w", padx=(depth * 18, 0), pady=1)

            child_secs = [n for n in sec.children if isinstance(n, Section)]

            if child_secs:
                arrow_var = tk.StringVar(value="\u25BE")  # ▾
                arrow_lbl = ttk.Label(row, textvariable=arrow_var, width=2, cursor="hand2")
                arrow_lbl.pack(side="left")
            else:
                ttk.Label(row, text="  ", width=2).pack(side="left")

            var = tk.BooleanVar(value=sec.enabled)
            self.section_vars[sec] = var

            if sec.name:
                label_text = sec.name
            elif sec.cls:
                label_text = f"[class: {sec.cls}]"
            else:
                label_text = f"(секция, строка {sec.line})"
            if sec.cls and sec.name:
                label_text += f"  [class: {sec.cls}]"

            cb = ttk.Checkbutton(
                row, text=label_text, variable=var,
                command=lambda s=sec, v=var: self.on_toggle(s, v),
            )
            cb.pack(side="left")

            if child_secs:
                child_container = ttk.Frame(parent)
                child_container.pack(fill="x", anchor="w")
                self.build_section_widgets(child_container, sec.children, depth + 1)

                def make_toggle(cc=child_container, av=arrow_var):
                    def _toggle(event=None):
                        if cc.winfo_ismapped():
                            cc.pack_forget()
                            av.set("\u25B8")  # ▸ свёрнуто
                        else:
                            cc.pack(fill="x", anchor="w")
                            av.set("\u25BE")  # ▾ развёрнуто
                    return _toggle

                arrow_lbl.bind("<Button-1>", make_toggle())

    def _restore_last_tab(self):
        if not self._saved_last_tab or not self.files:
            return
        for idx, filename in enumerate(sorted(self.files)):
            if filename == self._saved_last_tab:
                self.notebook.select(idx)
                return

    # ------------------------------------------------------------ логика -

    def _current_tab_filename(self):
        if not self.files:
            return None
        try:
            tab_id = self.notebook.select()
        except tk.TclError:
            return None
        if not tab_id:
            return None
        text = self.notebook.tab(tab_id, "text")
        return text if text in self.files else None

    def on_toggle(self, section, var):
        value = var.get()
        section.enabled = value
        if section.cls:
            for sibling in self.class_registry.get(section.cls, []):
                if sibling is not section:
                    sibling.enabled = value
                    sib_var = self.section_vars.get(sibling)
                    if sib_var is not None:
                        sib_var.set(value)

    def on_generate(self):
        filename = self._current_tab_filename()
        if filename is None:
            return

        if self.text_dirty:
            proceed = messagebox.askyesno(
                "Подтверждение",
                "Текст был изменён вручную. Перегенерация удалит изменения.\n"
                "Продолжить?",
            )
            if not proceed:
                return

        nodes = self.files[filename]["nodes"]
        result = render(nodes)
        result = result.replace(TICKET_PLACEHOLDER, self.ticket_var.get())
        self._set_output_text(result)
        self.status_var.set(f"Сгенерировано из «{filename}».")

    def on_reset(self):
        filename = self._current_tab_filename()
        if filename is None:
            return
        nodes = self.files[filename]["nodes"]
        sections = list(iter_sections(nodes))

        for sec in sections:
            sec.enabled = sec.default
            var = self.section_vars.get(sec)
            if var is not None:
                var.set(sec.default)

        # синхронизация классов после Reset (в пределах затронутых групп)
        for sec in sections:
            if sec.cls:
                for sibling in self.class_registry.get(sec.cls, []):
                    if sibling is not sec:
                        sibling.enabled = sec.enabled
                        sib_var = self.section_vars.get(sibling)
                        if sib_var is not None:
                            sib_var.set(sibling.enabled)

        self.status_var.set(f"Состояния вкладки «{filename}» сброшены.")

    def on_copy(self):
        text = self.output_text.get("1.0", "end-1c")
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_var.set("Текст скопирован в буфер обмена.")

    def _set_output_text(self, text):
        self._suppress_modified = True
        self.output_text.delete("1.0", "end")
        self.output_text.insert("1.0", text)
        self.output_text.edit_modified(False)
        self._suppress_modified = False
        self.text_dirty = False
        self.dirty_var.set("")

    def _on_text_modified(self, event=None):
        if self._suppress_modified:
            self.output_text.edit_modified(False)
            return
        if self.output_text.edit_modified():
            self.text_dirty = True
            self.dirty_var.set("* изменено вручную")
            self.output_text.edit_modified(False)

    def on_close(self):
        self._save_config()
        self.destroy()


def main():
    app = PromptConstructorApp()
    app.mainloop()


if __name__ == "__main__":
    main()
